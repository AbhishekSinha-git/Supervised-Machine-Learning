from flask import Flask, request, render_template, jsonify
import pickle
import cv2
from PIL import Image
import numpy as np
import os

app = Flask(__name__)

# Helper function to load a model
def load_model(model_name):
    # Model paths dictionary for easy access
    model_paths = {
        "Random Forest": "random_forest_model72.pkl",
        "K-Nearest Neighbors": "knn_model92_gb4.pkl",
        # Add other models here
    }
    model_path = model_paths[model_name]
    with open(model_path, 'rb') as file:
        model = pickle.load(file)
    return model

# Route to display the home page with form to upload images and select model
@app.route('/', methods=['GET'])
def home():
    return render_template('index.html')

# Route to handle the form submission and perform prediction
@app.route('/predict', methods=['POST'])
def predict():
    # Check if the post request has the file part
    if 'image' not in request.files:
        return "No file part"
    file = request.files['image']
    # If the user does not select a file, the browser submits an empty part without filename
    if file.filename == '':
        return 'No selected file'
    if file:
        image = Image.open(file.stream).convert('RGB')
        image_np = np.array(image)  # Convert PIL image to numpy array if needed for the model
        model_name = request.form['model']
        model = load_model(model_name)
        # Image preprocessing and prediction logic here
        # Placeholder for prediction, assuming the model takes numpy array directly
        prediction = model.predict(image_np.reshape(1, -1))
        return jsonify({'prediction': str(prediction)})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
