import streamlit as st
import cv2
from PIL import Image
import numpy as np
import os
import pickle
import matplotlib.pyplot as plt
from skimage.io import imread
from skimage.transform import resize
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import LabelEncoder
from skimage.filters import gaussian

# Define function to load model based on user selection
def load_model(model_name):
    if model_name == "Random Forest":
        model_path = "C://SYMBIOSISALL/sem4/SML/metalDefect_projectFile/random_forest_model72.pkl"
        # Load the model
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
    elif model_name == "K-Nearest Neighbors":
        model_path = "C://SYMBIOSISALL/sem4/SML/metalDefect_projectFile/knn_model92_gb4.pkl"
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
    elif model_name == "Support Vector Machine":
        model_path = "C://SYMBIOSISALL/sem4/SML/metalDefect_projectFile/svm_model8_gb4.pkl"
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
    elif model_name == "Naive Bayes":
        model_path = "C://SYMBIOSISALL/sem4/SML/metalDefect_projectFile/NB_model51_both4.pkl"
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
    return model

# Load labels
labels = ["No defect", "metal corrosion", "metal_crack", "metal dent"]

# Set page configuration
st.set_page_config(
    page_title="Metal Defect Detection",
    page_icon=":mag:",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("🛠️ Metal Defect Detection")
st.subheader("🔍 Discovering Imperfections: A Machine Learning Approach")

# Add a sidebar
with st.sidebar.expander("🚀 Navigation"):
    page = st.radio("", ["🏠 Home", "📚 About", "Metals Overview"])
    if page == "🏠 Home":
        st.sidebar.write("**🏠 Home**")
    elif page == "📚 About":
        st.sidebar.write("**📚 About**")
    else:
        st.sidebar.write("**Metals Overview**")

# About page content
if page == "📚 About":
    st.write("Welcome to our Metal Defect Detection website!")
    st.write("Our mission is to provide an innovative solution for detecting defects in metal, addressing the challenges faced by industries in maintaining quality standards and ensuring safety.")
    st.write("Key features of our project:")
    st.write("- Utilizes machine learning algorithms to detect multiple defects with accuracy.")
    st.write("- Detects defects in areas inaccessible to human inspection, enhancing safety measures.")
    st.write("- Employs a self-made dataset tailored to reflect the diverse landscape of metal defects.")
    st.write("- Highlights the importance of metal integrity in various industries and the potential hazards posed by undetected defects.")

# Metals Overview page content
elif page == "Metals Overview":
    st.write("### Metals Overview")
    st.write("Here's a comparison of different metals and their importance in various industries:")
    
    st.image("output.png", use_column_width=True)  # Add your comparison image here

    st.write("#### Bronze:")
    st.write("Bronze is a versatile and popular metal used in various industries thanks to its properties, including corrosion resistance and low friction levels. It’s used in everyday objects to grand architectural masterpieces, electrical connectors, and bearings.")

    st.write("#### Iron:")
    st.write("Iron is used for making automobiles, trains, ships, engines, tools, and many other items. It is also used in construction due to its strength and ability to withstand extreme temperatures and weather conditions.")

    st.write("#### Steel:")
    st.write("Steel plays a vital role in the modern world. In addition to being one of the most important materials for building and infrastructure, steel is the enabler of a wide range of manufacturing activities.")

    st.write("#### Stainless Steel:")
    st.write("Stainless steel is primarily made from medium and low-carbon steel. They are alloyed with a range of metals to alter the resulting properties. For example, chromium and nickel lend corrosion resistance and hardness.")

    st.write("#### Aluminum:")
    st.write("Aluminum is a lightweight, corrosion-resistant, highly malleable, and infinitely recyclable material which finds usage in multiple industries, including construction, transport, electrical equipment, machinery, and packaging.")

    st.write("#### Copper:")
    st.write("Copper is an incredibly versatile mineral and its properties – high flexibility, conformity, thermal & electrical conductivity, and resistance to corrosion – make it critical to our domestic manufacturing sector.")

    st.write("#### Nickel:")
    st.write("Nickel, with its remarkable properties and rich history, has established itself as a vital metal in various sectors. Its corrosion resistance, high melting point, mechanical strength, and conductivity make it an indispensable element in applications ranging from stainless steel production to aerospace engineering.")

# Home page content
else:
    model_name = st.sidebar.selectbox("Model Selection", ["K-Nearest Neighbors", "Random Forest", "Support Vector Machine", "Naive Bayes"])
    model_description = {
        "K-Nearest Neighbors": "K-Nearest Neighbors (KNN) is a simple algorithm that stores all available cases and classifies new cases based on a similarity measure (e.g., distance functions).",
        "Random Forest": "Random Forest is a versatile machine learning method capable of performing both regression and classification tasks. It is a type of ensemble learning method, where a group of weak models combine to form a powerful model.",
        "Support Vector Machine": "Support Vector Machine (SVM) is a powerful and versatile Machine Learning model, capable of performing linear or nonlinear classification, regression, and even outlier detection.",
        "Naive Bayes": "Naive Bayes classifiers are a family of simple 'probabilistic classifiers' based on applying Bayes' theorem with strong (naive) independence assumptions between the features."
    }
    st.sidebar.write(model_description[model_name])

    dataset_path = "C://SYMBIOSISALL/sem4/SML/metalDefect_projectFile/New_resized_img/"
    class_counts = {}

    # Iterate over all files in the dataset directory
    for class_name in os.listdir(dataset_path):
        class_path = os.path.join(dataset_path, class_name)
        if os.path.isdir(class_path):
            # Count the number of images in this class
            num_images = len(os.listdir(class_path))
            class_counts[class_name] = num_images

    # EDA section
    if st.sidebar.checkbox("Show Sample Images from Each Class"):
        # Show Sample Images
        st.write("### Sample Images from Each Class")
        plt.figure(figsize=(10, 10))
        for i, class_name in enumerate(class_counts.keys()):
            class_path = os.path.join(dataset_path, class_name)
            # Get the first image from this class
            image_name = os.listdir(class_path)[0]
            image_path = os.path.join(class_path, image_name)
            image = imread(image_path)
            # Plot the image
            plt.subplot(2, 2, i+1)
            plt.imshow(image, cmap='gray')
            plt.title(class_name)
            plt.axis('off')  # Turn off axis labels and ticks
        plt.tight_layout()
        st.pyplot()

    st.set_option('deprecation.showPyplotGlobalUse', False)
    # Upload image
    uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "png", "jpeg"])

    if uploaded_file is not None:
        image = Image.open(uploaded_file)
        st.image(image, caption='Uploaded Image', use_column_width=True)
        st.write("")
        st.write("Classifying...")

        # Convert the file to an opencv image.
        image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
        # Convert the image to grayscale
        image_resized = cv2.resize(image, (256, 256))
        image_gray = cv2.cvtColor(image_resized, cv2.COLOR_BGR2GRAY)
        img_blurred = gaussian(image_gray, sigma=1.0)
        # Convert the blurred image to float32
        img_blurred_float32 = img_blurred.astype(np.float32)

        # Flatten the image
        image_flattened = img_blurred_float32.flatten()

        # Reshape the flattened image to match the expected input shape of your model
        image_flattened = image_flattened.reshape(1, -1)

        # Run the image through the model
        prediction = load_model(model_name).predict(image_flattened)

        # Show the prediction
        st.success(f"This metal surface has a defect of type: {labels[prediction[0]]}")
       

# Team members' names
st.markdown(
    """
    <div style="position: fixed; bottom: 10px; right: 10px;">
        <p style="font-size: 12px;">Made by Aditi Dhavale, Abhishek Sinha, Amrut Ghadge, and Anshul Shinde</p>
    </div>
    """,
    unsafe_allow_html=True
)
